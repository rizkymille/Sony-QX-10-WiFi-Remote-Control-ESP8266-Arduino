
               Camera Remote API beta
             Sample code for Android(TM)
                                    Sony Corporation

  What is it?
  -----------
  This is sample code for Camera Remote API beta provided by Sony.
  This sample code is designed to run on Android.
  * Android is a trademark of Google Inc.

  Notice
  ------
  Please change the package name when you publish your applications.

  ChangeLog
  ---------
  2016-03-01
    Improve stability of transferring images function with compatible cameras.
    
  2015-10-30
    Update to Android Studio style project structure.
    Change Android minimum SDK version to 14.
    Remove connected access point SSID display in device discovery UI.
    Add transferring images function for the PlayMemories Camera Apps "Smart Remote Control" application. *
    Add remote playback function for the PlayMemories Camera Apps "Smart Remote Control" application. *
    * Not available on some models. Please see the API Reference for details.
    
  2014-09-01
    Add transferring images function for QX1, DSC-QX30 and HDR-AZ1.
    Add remote playback function for QX1, DSC-QX30 and HDR-AZ1.
    Minor bug fixes.
    
  2014-04-14
    Improve the user interface.
    Improve stability of connections with compatible cameras.
    
  2014-01-06
    Improve stability of connections with compatible cameras.
  
  2013-11-05
    Add zoom control function.
    Improve stability of connections with compatible cameras.
  
  2013-09-01
    First release
