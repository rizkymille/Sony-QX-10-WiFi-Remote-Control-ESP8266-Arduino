
                 Camera Remote API beta
              Sample code for iPhone/iPad
                                    Sony Corporation

  What is it?
  -----------
  This is sample code for Camera Remote API beta provided by Sony.
  This sample code is designed to run on iPhone/iPad.
  * iPhone is a trademark of Apple Inc.
  * iPad is a trademark of Apple Inc.

  ChangeLog
  ---------
  2015-10-30
    Remove connected access point SSID display in device discovery UI.
    Improve stability of Device Discovery (SSDP).
    Add transferring images function for the PlayMemories Camera Apps "Smart Remote Control" application. *
    Add remote playback function for the PlayMemories Camera Apps "Smart Remote Control" application. *
    * Not available on some models. Please see the API Reference for details.
    
  2015-04-20
    Improve stability of Device Discovery (SSDP).
    
  2014-10-30
    Minor bug fixes.
    
  2014-09-01
    Add transferring images function for QX1, DSC-QX30 and HDR-AZ1.
    Add remote playback function for QX1, DSC-QX30 and HDR-AZ1.
    Minor bug fixes.
    
  2014-06-18
    Improve stability of connections with compatible cameras.
  
  2014-04-14
    First release
