/**
 * @file  SampleContentCell.m
 * @brief CameraRemoteSampleApp
 *
 * Copyright 2014 Sony Corporation
 */

#import "SampleContentCell.h"

@implementation SampleContentCell

@end
